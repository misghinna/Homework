package assy10.form;

import com.sun.net.httpserver.HttpServer;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;


@WebServlet("/support")
public class SupportForm extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String supportForm = getServletContext().getInitParameter("form-servlet");
        PrintWriter page = resp.getWriter();
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        PrintWriter response = resp.getWriter();
        String fullName = req.getParameter("fname");
        String email = req.getParameter("emailfield");
        String supportEmail=getServletContext().getInitParameter("support-email");
        String confNo = req.getParameter("conf");
        response.print("<html><head><title>Support Form</title></head><body>");
        response.print("Thank you! " + fullName + " for contacting us.\n" +
                "You should receive reply from us with in 24 hrs in your email address " + email+"\n"+
                "Let us know in our support email " + supportEmail +
                "if you don&#39t receive reply within 24 hrs. Please be sure to attach your reference" +
                "[support_ticket_id] in your email.");
        response.print("<br><br>");
        response.print("Confirmation No.: " + confNo +" <br><br>");
        response.print("Contact us: "+supportEmail);
        response.print("</body></html>");
    }
}
